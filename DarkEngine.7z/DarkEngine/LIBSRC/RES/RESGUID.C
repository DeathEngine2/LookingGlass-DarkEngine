// $Header: x:/prj/tech/libsrc/res/RCS/resguid.c 1.2 1997/02/24 23:49:36 TOML Exp $

#include <comtools.h>
#include <initguid.h>
#include <resguid.h>


