/*
 * $Source: s:/prj/tech/libsrc/dev2d/RCS/nulcnv.c $
 * $Revision: 1.1 $
 * $Author: KEVIN $
 * $Date: 1996/04/10 16:05:30 $
 *
 * Fill constants.
 *
 * This file is part of the dev2d library.
 *
 */

#include <grnull.h>

void (*gdd_null_canvas_table[])()=
{
   gr_null,
   gr_null,
   gr_null,
   gr_null,

   gr_null,
   gr_null,
   gr_null,
   gr_null,

   gr_null,
   gr_null,
   gr_null,
   gr_null,
   gr_null,
   gr_null,
   gr_null,
   gr_null
};

