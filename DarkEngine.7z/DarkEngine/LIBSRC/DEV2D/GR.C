void gr_start_frame(){};
void gr_end_frame(){};
