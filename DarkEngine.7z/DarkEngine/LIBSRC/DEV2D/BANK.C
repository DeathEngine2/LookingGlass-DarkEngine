/*
 * $Source: s:/prj/tech/libsrc/dev2d/RCS/bank.c $
 * $Revision: 1.1 $
 * $Author: KEVIN $
 * $Date: 1996/04/10 15:57:27 $
 * 
 * Routines for drawing pixels into a flat 8 canvas.
 *
 * This file is part of the dev2d library.
 *
 * $Log: bank.c $
 * Revision 1.1  1996/04/10  15:57:27  KEVIN
 * Initial revision
 * 
 */

int gdd_ignore_bank=0;
int gdd_save_bank=0;
int gdd_bank;
